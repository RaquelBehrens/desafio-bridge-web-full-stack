import React, { Component } from 'react'
import { withRouter } from "react-router"

import TopNumberService from '../services/TopNumberService'


class ListTopNumberComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            topNumbers: []
        }

        this.addTopNumber = this.addTopNumber.bind(this);
        this.deleteTopNumber = this.deleteTopNumber.bind(this);
    }

    componentDidMount() {
        TopNumberService.getTopNumbers().then((res) => {
            this.setState({topNumbers: res.data});

        });
    }

    addTopNumber() {
        this.props.history.push("/calcular_top_number");
    }

    deleteTopNumber(number) {
        TopNumberService.deleteTopNumber(number).then( res => {
            this.setState({topNumbers: this.state.topNumbers.filter(topNumber.id !== number)})
        })
    }

    render() {
        return (
            <div>
                <h2 className='text-center'>Numbers List</h2>

                <div className='row'>
                    <button className='btn btn-primary' onClick={this.addTopNumber}>Calcular Novo Número</button>
                </div>

                <div className='row'>
                    <table className='table table-striped table-bordered'>
                        <thead>
                            <tr>
                                <th>Original Number</th>
                                <th>Result</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.topNumbers.map(
                                    topNumber =>
                                    <tr key={topNumber.id}>
                                        <td> {topNumber.result} </td>
                                        <td>
                                            <button onClick={ () => this.deleteTopNumber(topNumber.id)} className="btn btn-danger">Deletar</button>
                                        </td>
                                    </tr>
                                )
                            }
                        </tbody>

                    </table>
                </div>
            </div>
        )
    }
}

export default ListTopNumberComponent
